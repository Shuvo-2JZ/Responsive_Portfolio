<?php
return [
    'path'        => dirname( dirname( __FILE__ ) ),
    'url'         => plugin_dir_url( dirname( __FILE__ ) ),
    'module_path' => dirname( dirname( __FILE__ ) ) . '/modules',
    'view_path'   => dirname( dirname( __FILE__ ) ) . '/views',
    'pm_pro_file' => dirname( dirname( __FILE__ ) ) . '/cpm-pro.php',
];
