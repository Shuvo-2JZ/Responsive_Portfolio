<?php

return [
	'name'        => 'Project Manager Pro',
	'slug'        => 'pm-pro',
	'version' => '2.6.0',
    'db_version'  => '0.4',
	'api'         => '2',
	'text_domain' => 'pm-pro',
	'product_id'  => 'cpm-pro',
	'plan'        => 'cpm-business',
    'environment' => 'production',
];
